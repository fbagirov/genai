Place sample images here: street_sign.jpg, receipt.png, desk.jpg
